
<div class="slider">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<center>
					<div class="input-group" id="adv-search">
                        <center>
                            <h1>Eat Healthy. Stay Healthy.</h1>
                         </center>
					</div>
				</center>
			</div>
		</div>
	</div>
</div>
<br>



<div id="vegetables">
        <div class="container">

            <div class="row">
            <div class="col-md-3 col-sm-2">
                    <div class="veg img-border">
                        <img src="images/Red-Apple-PNG-Image.png" class="veg-img">
                        <div class="overlay"></div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-2">
                    <div class="veg img-border">
                        <img src="images/1746477_87218b24-3f31-4f2a-b809-c7bdac8c17ca.png" class="veg-img">
                        <div class="overlay"></div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-2">
                    <div class="veg img-border">
                        <img src="images/pomegranate2.png" class="veg-img">
                        <div class="overlay"></div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-2">
                    <div class="veg img-border">
                        <img src="images/ananas.jpg" class="veg-img">
                        <div class="overlay"></div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-2">
                    <div class="veg img-border">
                        <img src="images/cauliflower-1kg_754473d3-2fa5-4630-8ee7-63a97695b568_large.jpg" class="veg-img">
                        <div class="overlay"></div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-2">
                    <div class="veg img-border">
                        <img src="images/8885003329011_0008_1476354573739.jpg" class="veg-img">
                        <div class="overlay"></div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-2">
                    <div class="veg img-border">
                        <img src="images/0384.jpg" class="veg-img">
                        <div class="overlay"></div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-2">
                    <div class="veg img-border">
                        <img src="images/spruit.jpg" class="veg-img">
                        <div class="overlay"></div>
                    </div>
                </div>

                 <div class="col-md-3 col-sm-2">
                    <div class="veg img-border">
                        <img src="images/caramello-cake-105070-1.jpeg" class="veg-img">
                        <div class="overlay"></div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-2">
                    <div class="veg img-border">
                        <img src="images/cake.jpg" class="veg-img">
                        <div class="overlay"></div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-2">
                    <div class="veg img-border">
                        <img src="images/4876492-3x2-940x627.jpg" class="veg-img">
                        <div class="overlay"></div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-2">
                    <div class="veg img-border">
                        <img src="images/capsicum-chilli-jam-recipe-header.jpg" class="veg-img">
                        <div class="overlay"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <br>
