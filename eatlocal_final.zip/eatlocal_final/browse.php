<?php
if(session_id() == '' || !isset($_SESSION)){session_start();}
include 'config.php';
?>
<div class="all">
	<div class="container">
		<div class="row">
			<!-- browse menu-->
			<div class="col-sm-3">
				<div class="box">
					<ul>
						<li>
							<h6>
								<i class="fas fa-greater-than mryt-10"></i>Vegetables</h6>
						</li>

						<li>
							<h6>
								<i class="fas fa-angle-down mryt-10"></i>fruits</h6>
							<ul>
								<li>Apple</li>
								<li>Banana</li>
								<li>Grapes</li>
								<li>Pear</li>
								<li>Peach</li>
								<li>Plum</li>
								<li>Avocado</li>
								<li>Blueberry</li>
							</ul>
						</li>
						<li>
							<h6>
								<i class="fas fa-angle-down mryt-10"></i>Homemade Food</h6>
							<ul>
								<li>Jam</li>
								<li>Honey</li>
								<li>Cake</li>
								<li>Bread</li>
							</ul>
						</li>

					</ul>
				</div>
			</div>
			<!--menu completed-->
			<!-- gallery-->
			<div class="col-md-9">
				<div class="container">
					<div class="row">
						<div class="col-md-12 col-sm-12">
							<div class="input-group" id="">
								<!-- <input type="text" class="form-control" placeholder="I'm looking for" />
								<div class="input-group-btn">
									<div class="btn-group" role="group">
										<button type="button" class="btn btn-clr">
											<div>
												<i class="fa fa-search"></i>
											</div>
										</button>
									</div>
								</div> -->
							</div>
						</div>
					</div>
					<center>
						<h2>vegetables</h2>
					</center>
					<div class="row">
					<?php
          $i=0;
          $product_id = array();
          $product_quantity = array();

          $result = $mysqli->query('SELECT * FROM products');
          if($result === FALSE){
            die(mysql_error());
          }

          if($result){

            while($obj = $result->fetch_object()) {

			  echo '<div class="col-md-4 col-sm-2">';
			  echo '<div class="veg img-border">';
			  echo '<img src="images/'.$obj->product_img_name.'" class="veg-img">';
			  echo'<div class="overlay">'.$obj->product_name.' '.$currency.$obj->price.'</div>';
			  echo '</div>';
			  
			  if($obj->qty > 0){
                echo'<div><a href="update-cart.php?action=add&id='.$obj->id.'"><input type="submit" value="Add To Cart" class="btn btn-primary col-md-6 offset-md-3" /></a></div>';
              }
              else {
                echo '<div class="col-md-6 offset-md-3"> Out Of Stock! </div>';
              }
			  echo'</div>';

              $i++;
            }

          }

          $_SESSION['product_id'] = $product_id;


        //   echo '</div>';
        //   echo '</div>';
          ?>
		  </div>
					
				</div>
			</div>
			<!--gallery completed-->
		</div>
	</div>
</div>
<br>