<?php
// Include config file
require_once 'config.php';?>
//getting the categories

