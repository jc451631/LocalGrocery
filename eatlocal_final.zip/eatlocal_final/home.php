
		<div class="container-fluid">	
				<div class="row" style="padding-top: 0.5em;">
					<div class="col-md-1">
					</div>
					<div class="col-md-10 schimg" style="padding-top: 10em; padding-bottom: 10em; border-bottom-style:solid; border-color:#0C0";">
						<div class="container-fluid">
							<div class="row">
								<div class="col">
								</div>
								<div class="col">
                                    <div class="search-container">
    									<form class="example" action="index.php?page=browse" style="margin:auto;max-width:800px">
  											<input type="hidden" name="page" value="browse">
  											<input type="text" placeholder="Search.." name="search2">
  											<button type="submit"><i class="fa fa-search"></i></button>
                                        </form>
  									</div>
								</div>
								<div class="col">
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-1">
					</div>
				</div>		
		</div>

			
		<div class="col-md-1">
		</div>
        <div class="container-fluid  col-md-10">
            	<h2>Feature Ads</h2>
				<div class="ad">
					<img src="images/ad1.jpg">
				</div>
				<div class="ad">
					<img src="images/ad2.jpg">
				</div>
				<div class="ad">
					<img src="images/ad3.jpg">
				</div>
				<div class="ad">
					<img src="images/ad4.jpg">
				</div>
			
				<div class="ad">
					<img src="images/ad1.jpg">
				</div>
				<div class="ad">
					<img src="images/ad2.jpg">
				</div>
				<div class="ad">
					<img src="images/ad3.jpg">
				</div>
				<div class="ad">
					<img src="images/ad4.jpg">
				</div>
                
			<div class="col-md-1">
			</div>
		</div>

