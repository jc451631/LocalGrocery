<!doctype html>

<html lang="en">

	<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">

		<link href="test.css" rel="stylesheet" type="text/css">
        <link href="listing.css" rel="stylesheet" type="text/css">
        
        

		<!-- Optional JavaScript -->
		<!-- jQuery first, then Popper.js, then Bootstrap JS -->
		<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script>
        
        

	<title>eatLocal - Listing</title>
	</head>
    
	<body>
		<!-- Navigation -->
		<nav class="navbar sticky-top navbar-expand-sm navbar-dark bg-success">
			<a class="navbar-brand" href="#"><img src="images/LOGO.png" alt="LOGO" width="130em"></a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" 				aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>

			<div class="collapse navbar-collapse" id="navbarSupportedContent">
				<ul id="cats">
				
				
				
				<ul>
                <ul class="navbar-nav mr-auto">
					<li class="nav-item"><a class="nav-link" href="#">Vegatables</a></li>
					<li class="nav-item"><a class="nav-link" href="#">Fruit</a></li>
					<li class="nav-item"><a class="nav-link" href="#">Homemade Food</a></li>
				</ul>
				<ul class="navbar-nav navbar-right">
					<li class="nav-item"><a class="nav-link" href="#"><span>X</span>Log In</a></li>
					<li class="nav-item"><a class="nav-link" href="#"><span>X</span>Sign Up</a></li>
				</ul>
			</div>
            <div id="form">
				<form method="get" action="results.php" enctype="multipart/form-data">
					<input type="text" name="user_query" placeholder="Search a Product"/> 
					<input type="submit" name="search" value="Search" />
				</form>
			
			</div>
		</nav>
        
        <div class="bg"> 
		<section id="loginform" class="outer-wrapper">
		<div class="inner-wrapper">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-3"></div>
					<div class="col-md-6">
						<h2 class="text-center">List your Products</h2>
							<form role="form">
								<div class="row">
									<div class="col">
										<label for="exampleInputEmail1">Title</label>
										<input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter Title">
									</div>
								</div>
								<div class="row">
									<div class="col">
										<label for="exampleInputPassword1">Category</label>
										<select name="cars" class="form-control" id="catogory" placeholder="Select a category">
    									<option value="volvo">Vagetable</option>
    									<option value="saab">Fruit</option>
    									<option value="fiat">Homemade Food</option>
  										</select>
									</div>
								</div>
                                
                                <div class="row">
                                	<div class="col">
										<label for="exampleInputEmail1">Discription</label>
                                        <textarea name="message" class="form-control" rows="5" cols="30" placeholder="Describe your products"></textarea>
									</div>
                                </div>
                                
                                 <div class="row">
									<div class="col">
										<label for="exampleInputPassword1">Price/Unit</label>
										<input type="price" class="form-control" id="exampleInputPassword1" placeholder="$">
									</div>
                                    <div class="col">
										<label for="exampleInputPassword1">Unit</label>
										<select name="cars" class="form-control" id="unit"holder="Select a unit">
    									<option value="kg">kg</option>
    									<option value="ml">ml</option>
    									<option value="each">each</option>
  										</select>
									</div>
								</div>
                                
                                
                                <div class="row">
									<div class="col">
										<label for="exampleInputPassword1">Location</label>
										<input type="password" class="form-control" id="exampleInputPassword1" placeholder="Location">
									</div>
								</div>
								
                                <div class="row">
									<div class="col">
										<center><button type="submit" class="btn btn-default">Submit</button></center>
									</div>
								</div>
							</form>
						</div>
					</div>
					<div class="col-md-3"></div>
				</div>
			</div>
		</section>
    	</div>

	</body>
</html>
